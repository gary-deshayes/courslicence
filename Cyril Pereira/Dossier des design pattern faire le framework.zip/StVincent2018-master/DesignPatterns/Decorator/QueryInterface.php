<?php

interface QueryInterface
{
    /**
     * Returns the list of queries.
     *
     * @return array
     */
    public function getQueries();
}
