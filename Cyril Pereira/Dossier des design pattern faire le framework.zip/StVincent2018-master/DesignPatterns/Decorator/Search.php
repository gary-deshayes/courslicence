<?php

class Search implements QueryInterface
{
    /**
     * Search constructor.
     */
    public function __construct()
    {
    }

    /**
     * @return array
     */
    public function getQueries()
    {
        return [];
    }
}
