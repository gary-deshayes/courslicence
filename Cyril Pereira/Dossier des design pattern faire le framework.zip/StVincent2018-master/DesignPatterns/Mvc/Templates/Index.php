<html>
<body>
<h1>Hello <?php echo $this->name; ?></h1>
<ul>in the url try other queries
  <li><a href="?controller=index&action=index">Index</a></li>
  <li><a href="?controller=index&action=page">Page</a></li>
  <li><a href="?controller=index&action=list">List</a></li>
  <li><a href="?controller=index&action=your_choice">NotFound</a></li>
</ul>

<a href="?"></a>
</body>
</html>
