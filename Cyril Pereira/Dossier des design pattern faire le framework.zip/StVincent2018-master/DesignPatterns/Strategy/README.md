# Design Pattern : Strategy

### How to use

```bash
$ php index.php xml
```

```bash
$ php index.php json
```


