<?php

/**
 * Interface FormatInterface.
 */
interface FormatInterface
{
    /**
     * @param array $data
     */
    public function convert($data);
}
