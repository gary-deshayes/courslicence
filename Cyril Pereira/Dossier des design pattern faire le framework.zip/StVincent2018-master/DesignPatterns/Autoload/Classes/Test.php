<?php

namespace Classes;

class Test
{
    public function __construct()
    {
    }
}
