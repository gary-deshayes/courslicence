<?php

class Bar
{
}
