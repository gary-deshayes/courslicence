# Autoload

### How to use

Example of the `PSR-0`

```bash
$ php psr0.php
```

Example of the `PSR-4`

```bash
$ php psr4.php
```
