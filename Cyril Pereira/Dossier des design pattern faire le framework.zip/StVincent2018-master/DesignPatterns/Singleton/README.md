# Design Pattern : Singleton

## How to use

```bash
$ php index.php
```
