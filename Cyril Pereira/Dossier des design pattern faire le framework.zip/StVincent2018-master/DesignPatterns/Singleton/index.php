<?php

include 'Singleton.php';

$singleton = Singleton::getInstance();
var_dump($singleton);
