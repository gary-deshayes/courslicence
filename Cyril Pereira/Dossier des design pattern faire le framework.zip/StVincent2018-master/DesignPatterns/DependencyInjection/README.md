# Dependency Injection

In this example you can see we add POD to the container under the name `database`.

### How to use

```bash
$ php index.php
```

